package main.entities.characters;

public class Military {

}
