package main.entities.characters;

public class Police {

}
