package main.levels;

public class Level2 {

}
