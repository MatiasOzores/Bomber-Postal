package main.entities.characters;

public class Innocent {

}
