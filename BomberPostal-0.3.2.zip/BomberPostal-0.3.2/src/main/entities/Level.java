package main.entities;

import java.awt.Color;

import main.entities.environment.Structure;

public class Level {
	public Level() {

	}
	
	public void update() {
	
	}
	
	public void draw() {
		
	}
}
