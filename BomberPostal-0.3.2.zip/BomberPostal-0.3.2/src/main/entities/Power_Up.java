package main.entities;

import java.awt.Color;
import java.awt.Graphics;

public class Power_Up {
    private int x, y, width, height;
    public int tipo;
    private Color color;
    
    public Power_Up(int x, int y, int tipo) {
        this.x = x;
        this.y = y;
        this.width = 20;  // Tamaño del power-up
        this.height = 20; // Tamaño del power-up
        this.color = Color.YELLOW; // Puedes cambiar el color si quieres
        this.tipo = tipo;
    }

    public void draw(Graphics g) {
        g.setColor(color);
        g.fillRect(x, y, width, height);
    }

    // Getters para la detección de colisiones
    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }
}
