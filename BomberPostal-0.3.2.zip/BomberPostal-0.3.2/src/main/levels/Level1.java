package main.levels;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.imageio.ImageIO;

import main.entities.environment.Structure;
import main.ui.Window;

public class Level1 {

	
	// ----------------------- Declaracion de variables
	
	private int invalido = 0;
	
    private Image barraLateralImage;
	
    private Image 
    
    N1F1PA1,N1F1PA2,N1F1PA3,N1F1PA4,N1F1PA5,N1F1PA6,N1F1PA7,N1F1PA8,N1F1PA9,N1F1INTERIOR, N1F1SUELO, N1F1BORDE, N1F1ESQ_IZQ_INF, 
    N1F1ESQ_IZQ_SUP, N1F1ESQ_DER_INF, N1F1ESQ_DER_SUP, N1F1PD, N1F1PL, N1F1PR ,N1F1PU, impresora, planta, trapeador,
    
    N1F2PA1,N1F2PA2,N1F2PA3,N1F2PA4,N1F2PA5,N1F2PA6,N1F2PA7,N1F2PA8,N1F2PA9,N1F2INTERIOR, N1F2SUELO, N1F2BORDE, N1F2ESQ_IZQ_INF, 
    N1F2ESQ_IZQ_SUP, N1F2ESQ_DER_INF, N1F2ESQ_DER_SUP, N1F2PD, N1F2PL, N1F2PR ,N1F2PU, latas,
    
    N1F3PA, N1F3SUELO, N1F3BORDE, N1F3ESQ_IZQ_INF, N1F3ALFOMBRA ,
    N1F3ESQ_IZQ_SUP, N1F3ESQ_DER_INF, N1F3ESQ_DER_SUP, N1F3PD, N1F3PL, N1F3PR ,N1F3PU;  

	// ----------------------- Fin de Declaracion de variables
	
	// Constructor
	public Level1() {
        try {
            barraLateralImage = ImageIO.read(new File("assets/images/lateralImage.jpg"));
            N1F1PA1 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/ParedOficinaColumna.png"));
            N1F1PA2 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/ParedOficinaExtremoDerecho.png"));
            N1F1PA3 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/ParedOficinaExtremoInferior.png"));
            N1F1PA4 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/ParedOficinaExtremoIzquierdo.png"));
            N1F1PA5 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/ParedOficinaExtremoSuperior.png"));
            N1F1PA6 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/ParedOficinaInferiorDerecho.png"));
            N1F1PA7 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/ParedOficinaInferiorIzquierdo.png"));
            N1F1PA8 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/ParedOficinaSuperiorDerecho.png"));
            N1F1PA9 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/ParedOficinaSuperiorIzquierdo.png"));
            N1F1PD = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/ParedOficinaConexionDown.png"));
            N1F1PL = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/ParedOficinaConexionLeft.png"));
            N1F1PR = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/ParedOficinaConexionRight.png"));
            N1F1PU = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/ParedOficinaConexionUp.png"));
            N1F1SUELO = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/BaldosaOficina.png"));
            N1F1BORDE= ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/BloqueBordeOficina.png"));
            N1F1INTERIOR = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/InteriorPared.png"));
            N1F1ESQ_IZQ_INF = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/BordeOficinaEsquinaInferiorIzquierda.png"));
            N1F1ESQ_IZQ_SUP = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/BordeOficinaEsquinaSuperiorIzquierda.png"));
            N1F1ESQ_DER_INF = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/BordeOficinaEsquinaInferiorDerecha.png"));
            N1F1ESQ_DER_SUP = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/BordeOficinaEsquinaSuperiorDerecha.png"));
            impresora = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/Impresora.png"));
            planta = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/Planta.png"));
            trapeador = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/Trapeador.png"));
            
            N1F2PA1 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/ParedSuperColumna.png"));
            N1F2PA2 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/ParedSuperExtremoDerecho.png"));
            N1F2PA3 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/ParedSuperExtremoInferior.png"));
            N1F2PA4 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/ParedSuperExtremoIziquierdo.png"));
            N1F2PA5 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/ParedSuperExtremoSuperior.png"));
            N1F2PA6 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/ParedSuperInferiorDerecho.png"));
            N1F2PA7 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/ParedSuperInferiorIzquierdo.png"));
            N1F2PA8 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/ParedSuperSuperiorDerecho.png"));
            N1F2PA9 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/ParedSuperSuperiorIzquierdo.png"));
            N1F2SUELO = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/BaldosaSupermercado.png"));
            N1F2BORDE= ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/BloqueBordeSupermercado.png"));
            N1F2ESQ_IZQ_INF = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/BordeSuperEsquinaInferiorIzquierda.png"));
            N1F2ESQ_DER_INF = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/BordeSuperEsquinaInferiorDerecha.png"));
            N1F2ESQ_DER_SUP = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/BordeSuperEsquinaSuperiorDerecha.png")); 
            N1F2ESQ_IZQ_SUP = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/BordeSuperEsquinaSuperiorIzquierda.png"));
            latas = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/latas.png"));
            
            N1F3ALFOMBRA = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/3_Banco/AlfombraBanco.png"));
            N1F3BORDE = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/3_Banco/BloqueBordeBanco.png"));
            N1F3PA = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/3_Banco/ParedBanco.png"));
            N1F3SUELO = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/3_Banco/PisoBanco.png"));
            N1F3ESQ_IZQ_INF = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/3_Banco/BordeBancoEsquinaInferiorIzquierda.png"));
            N1F3ESQ_DER_INF = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/3_Banco/BordeBancoEsquinaInferiorDerecha.png"));
            N1F3ESQ_DER_SUP = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/3_Banco/BordeBancoEsquinaSuperiorDerecha.png")); 
            N1F3ESQ_IZQ_SUP = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/3_Banco/BordeBancoEsquinaSuperiorIzquierda.png"));
            
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
	
	public void update(int frameSeleccionado, List<Structure> structures, int bloqueTam, int offsetX, int offsetY) {
		    if(frameSeleccionado == 1 && invalido != 1) {

			    invalido = 1;
		    }   
		    
		    else if(frameSeleccionado == 2 && invalido != 1) {


			    invalido = 1;
		    } 
		    else if(frameSeleccionado == 3 && invalido != 1) {
		    	
	
		    	invalido = 1;
		    } 
		    
		    
	}
	
	public void draw(Graphics g, int numColumnas, int numFilas, int bloqueTam, int offsetX, int offsetY, int frameSeleccionado) {
	    for (int i = 0; i < numColumnas; i++) {
	        for (int j = 0; j < numFilas; j++) {
	            int x = offsetX + i * bloqueTam;
	            int y = offsetY + j * bloqueTam;
            	if(frameSeleccionado == 1) {
            		
            		// Arriba a la izquierda
            		if(j == 0 && i == 0) {
		            	g.drawImage(N1F1ESQ_IZQ_SUP, x, y, bloqueTam, bloqueTam, null);
            		}
            		
            		// Arriba a la derecha
            		else if(j == 0 && i == numColumnas-1) {
		            	g.drawImage(N1F1ESQ_DER_SUP, x, y, bloqueTam, bloqueTam, null);
            		}
            		
            		// Abajo a la derecha
            		else if(j == numFilas-1 && i == numColumnas-1) {
		            	g.drawImage(N1F1ESQ_DER_INF, x, y, bloqueTam, bloqueTam, null);
            		}
            		
            		// Abajo a la izquierda
            		else if(j == numFilas-1 && i == 0) {
		            	g.drawImage(N1F1ESQ_IZQ_INF, x, y, bloqueTam, bloqueTam, null);
            		}
            		
            		// Bordes de arriba 
            		else if(j == 0) {
		            	g.drawImage(N1F1BORDE, x, y, bloqueTam, bloqueTam, null);		            		
	            	}
	            	
            		// Bordes de abajo
	            	else if(j == numFilas - 1) {
	            	    Graphics2D g2d = (Graphics2D) g.create(); 
	            	    
	            	    g2d.rotate(Math.toRadians(180), x + bloqueTam / 2, y + bloqueTam / 2);
	            	    
	            	    g2d.drawImage(N1F1BORDE, x-1, y-1, bloqueTam, bloqueTam, null);
	            	    
	            	    g2d.dispose(); 
	            	}
	            	
            		// Bordes de la izquierda
	            	else if(i == 0) {
	            	    Graphics2D g2d = (Graphics2D) g.create(); 
	            	    
	            	    g2d.rotate(Math.toRadians(-90), x + bloqueTam / 2, y + bloqueTam / 2);
	            	    
	            	    g2d.drawImage(N1F1BORDE, x-1, y, bloqueTam, bloqueTam, null);
	            	    g2d.dispose(); 
	            	    
	            	    Window.limiteJugadorArriba = bloqueTam * 1 + offsetX;
	            	    Window.limiteJugadorDerecha = (int)(bloqueTam * 13.25 + offsetX);
	            	    Window.limiteJugadorIzquierda = (int)(bloqueTam * 1+ offsetY);
	            	    Window.limiteJugadorAbajo = (int)(bloqueTam * 8.25 + offsetY);
	            	}
	            	
            		// Bordes de la derecha
	            	else if(i == numColumnas - 1) {
	            	    Graphics2D g2d = (Graphics2D) g.create(); 
	            	    
	            	    g2d.rotate(Math.toRadians(90), x + bloqueTam / 2, y + bloqueTam / 2);
	            	    
	            	    g2d.drawImage(N1F1BORDE, x, y-1, bloqueTam, bloqueTam, null);
	            	    
	            	    g2d.dispose(); 	
	            	    

	            	}

	            		
            		// Suelo
	            	else {
	            		g.drawImage(N1F1SUELO, x, y, bloqueTam, bloqueTam, null);
	            	}
            	}
	            
	            	
	            	if(frameSeleccionado == 2) {
	            		
	            		// Arriba a la izquierda
	            		if(j == 0 && i == 0) {
			            	g.drawImage(N1F2ESQ_IZQ_SUP, x, y, bloqueTam, bloqueTam, null);
	            		}
	            		
	            		// Arriba a la derecha
	            		else if(j == 0 && i == numColumnas-1) {
			            	g.drawImage(N1F2ESQ_DER_SUP, x, y, bloqueTam, bloqueTam, null);
	            		}
	            		
	            		// Abajo a la derecha
	            		else if(j == numFilas-1 && i == numColumnas-1) {
			            	g.drawImage(N1F2ESQ_DER_INF, x, y, bloqueTam, bloqueTam, null);
	            		}
	            		
	            		// Abajo a la izquierda
	            		else if(j == numFilas-1 && i == 0) {
			            	g.drawImage(N1F2ESQ_IZQ_INF, x, y, bloqueTam, bloqueTam, null);
	            		}
	            		
	            		// Bordes de arriba 
	            		else if(j == 0) {
			            	g.drawImage(N1F2BORDE, x, y, bloqueTam, bloqueTam, null);		            		
		            	}
		            	
	            		// Bordes de abajo
		            	else if(j == numFilas - 1) {
		            	    Graphics2D g2d = (Graphics2D) g.create(); 
		            	    
		            	    g2d.rotate(Math.toRadians(180), x + bloqueTam / 2, y + bloqueTam / 2);
		            	    
		            	    g2d.drawImage(N1F2BORDE, x-1, y-1, bloqueTam, bloqueTam, null);
		            	    
		            	    g2d.dispose(); 
		            	}
		            	
	            		// Bordes de la izquierda
		            	else if(i == 0) {
		            	    Graphics2D g2d = (Graphics2D) g.create(); 
		            	    
		            	    g2d.rotate(Math.toRadians(-90), x + bloqueTam / 2, y + bloqueTam / 2);
		            	    
		            	    g2d.drawImage(N1F2BORDE, x-1, y, bloqueTam, bloqueTam, null);
		            	    g2d.dispose(); 
		            	    
		            	    Window.limiteJugadorArriba = bloqueTam * 1 + offsetX;
		            	    Window.limiteJugadorDerecha = (int)(bloqueTam * 13.25 + offsetX);
		            	    Window.limiteJugadorIzquierda = (int)(bloqueTam * 1+ offsetY);
		            	    Window.limiteJugadorAbajo = (int)(bloqueTam * 8.25 + offsetY);
		            	}
		            	
	            		// Bordes de la derecha
		            	else if(i == numColumnas - 1) {
		            	    Graphics2D g2d = (Graphics2D) g.create(); 
		            	    
		            	    g2d.rotate(Math.toRadians(90), x + bloqueTam / 2, y + bloqueTam / 2);
		            	    
		            	    g2d.drawImage(N1F2BORDE, x, y-1, bloqueTam, bloqueTam, null);
		            	    
		            	    g2d.dispose(); 	
		            	    

		            	}

		            		
	            		// Suelo
		            	else {
		            		g.drawImage(N1F2SUELO, x, y, bloqueTam, bloqueTam, null);
		            	} 
	            	}
	            	
	            	
	            	if(frameSeleccionado == 3) {
	            		
	            		// Arriba a la izquierda
	            		if(j == 0 && i == 0) {
			            	g.drawImage(N1F3ESQ_IZQ_SUP, x, y, bloqueTam, bloqueTam, null);
	            		}
	            		
	            		// Arriba a la derecha
	            		else if(j == 0 && i == numColumnas-1) {
			            	g.drawImage(N1F3ESQ_DER_SUP, x, y, bloqueTam, bloqueTam, null);
	            		}
	            		
	            		// Abajo a la derecha
	            		else if(j == numFilas-1 && i == numColumnas-1) {
			            	g.drawImage(N1F3ESQ_DER_INF, x, y, bloqueTam, bloqueTam, null);
	            		}
	            		
	            		// Abajo a la izquierda
	            		else if(j == numFilas-1 && i == 0) {
			            	g.drawImage(N1F3ESQ_IZQ_INF, x, y, bloqueTam, bloqueTam, null);
	            		}
	            		
	            		// Bordes de arriba 
	            		else if(j == 0) {
			            	g.drawImage(N1F3BORDE, x, y, bloqueTam, bloqueTam, null);		            		
		            	}
		            	
	            		// Bordes de abajo
		            	else if(j == numFilas - 1) {
		            	    Graphics2D g2d = (Graphics2D) g.create(); 
		            	    
		            	    g2d.rotate(Math.toRadians(180), x + bloqueTam / 2, y + bloqueTam / 2);
		            	    
		            	    g2d.drawImage(N1F3BORDE, x-1, y-1, bloqueTam, bloqueTam, null);
		            	    
		            	    g2d.dispose(); 
		            	}
		            	
	            		// Bordes de la izquierda
		            	else if(i == 0) {
		            	    Graphics2D g2d = (Graphics2D) g.create(); 
		            	    
		            	    g2d.rotate(Math.toRadians(-90), x + bloqueTam / 2, y + bloqueTam / 2);
		            	    
		            	    g2d.drawImage(N1F3BORDE, x-1, y, bloqueTam, bloqueTam, null);
		            	    g2d.dispose(); 
		            	    
		            	    Window.limiteJugadorArriba = bloqueTam * 1 + offsetX;
		            	    Window.limiteJugadorDerecha = (int)(bloqueTam * 13.25 + offsetX);
		            	    Window.limiteJugadorIzquierda = (int)(bloqueTam * 1+ offsetY);
		            	    Window.limiteJugadorAbajo = (int)(bloqueTam * 8.25 + offsetY);
		            	}
		            	
	            		// Bordes de la derecha
		            	else if(i == numColumnas - 1) {
		            	    Graphics2D g2d = (Graphics2D) g.create(); 
		            	    
		            	    g2d.rotate(Math.toRadians(90), x + bloqueTam / 2, y + bloqueTam / 2);
		            	    
		            	    g2d.drawImage(N1F3BORDE, x, y-1, bloqueTam, bloqueTam, null);
		            	    
		            	    g2d.dispose(); 	
		            	    

		            	}

		            		
	            		// Suelo
		            	else {
		            		g.drawImage(N1F3ALFOMBRA, x, y, bloqueTam, bloqueTam, null);
		            	} 
	            	}
	        }
	    }
	}
}
