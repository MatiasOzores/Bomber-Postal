package main.ui;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferStrategy;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;
import main.entities.characters.Player;
import main.entities.environment.Structure;
import main.levels.Level1;

public class Window extends JFrame implements Runnable, KeyListener {

	// -------------------------- Declaracion de variables --------------------------
	
	// Configuraciones generales -------------------
	
	private static final long serialVersionUID = 1L;
    public static int WIDTH = 1280;
	public static int HEIGHT = 720;
    public static int alturaResponsive;
    public static int anchoResponsive;
	private Canvas canvas;
	private Thread thread;
	private boolean running;
	
	// Declaracion de graficos -----------------
	private BufferStrategy bs;
	private Graphics g;
	
	// Limitacion de FPS ----------------------
	private final int FPS = 60;
	private double TARGETTIME = 1000000000/FPS;
	private double delta = 0;
	
	// Declaracion de entidades ---------------------------
	
	// Personajes
    private Player player;
    
    // Entorno
    List<Structure> structures = new ArrayList<>();
    
    // Proyectiles
    
    // PowerUps
    
	// Fin de Declaracion de entidades ---------------------------
       
    // Declaracion de eventos del teclado ----------
    private boolean leftPressed = false;
    private boolean rightPressed = false;
    private boolean upPressed = false;
    private boolean downPressed = false;
    private boolean space = false;
    private boolean aPressed = false;
    private boolean dPressed = false;
    private boolean wPressed = false;
    private boolean sPressed = false;
    private boolean cPressed = false;
    
    // Controlar la resolucion
    public int resolucion = 2;
    
    // Tabla lateral derecha
    public static int puntuacion = 0;
    
    // Cronómetro
    private long startTime;
    private long elapsedTime; 
    
    // Controlar niveles y frames
    public int nivelSeleccionado = 1;
    public int frameSeleccionado = 1;
    
    Font font = new Font("Dirty Headline", Font.BOLD, (int)(Window.anchoResponsive * 0.06));
    
    // Establecer limites del jugador con los bordes
    public static int limiteJugadorIzquierda, limiteJugadorDerecha, limiteJugadorArriba, limiteJugadorAbajo;
    
    // Manejo de niveles
    private Level1 level1;
    
    // Variables pos-optimizacion
    
    public static int entitiesSize = 0;
    public static int bloqueTam;
    public static int offsetX,offsetY;
	// ------------------------------------------------------------------------------ Fin de Declaracion de Variables
    
    // Constructor

	public Window() {
		// ----------------------------------- Configuraciones principales
        setTitle("Bomber Postal");
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(true);
        setLocationRelativeTo(null);
        setVisible(true);
		
		canvas = new Canvas();
		canvas.setPreferredSize(new Dimension(WIDTH, HEIGHT));
		canvas.setFocusable(true);
		add(canvas);
	    canvas.addKeyListener(this);
	    
	    
        startTime = System.nanoTime();
		// ----------------------------------- Fin de Configuraciones principales
	    
        // ---------------- Instanciamiento de entidades
        
        player = new Player(200, 200, entitiesSize, entitiesSize, 3, 5);   

        // ---------------- Fin de Instanciamiento de entidades

        // ---------------- Instanciamiento de niveles
        
        level1 = new Level1();
        
        
        
        // ---------------- Fin de Instanciamiento de niveles
	}
	
	// Metodo que actualizara todo el juego (cada segundo literalmente)
	
	private void update() {
		
		// Actualizacion a tiempo real del tamaño de la ventana
	    setSize(WIDTH, HEIGHT);
	    canvas.setPreferredSize(new Dimension(WIDTH, HEIGHT));
	    canvas.revalidate();
		
		// ---------------------------------------- Control de resolucion
	    switch (resolucion) {
	        case 1:
	            WIDTH = 1800;
	            HEIGHT = 900;
	            break;
	        case 2:
	            WIDTH = 1280;
	            HEIGHT = 720;
	            bloqueTam = 60;
	            break;
	        case 3:
	            WIDTH = 1366;
	            HEIGHT = 768;
	            break;
	        case 4:
	            WIDTH = 1024;
	            HEIGHT = 768;
	            break;
	        case 5:
	            WIDTH = 800;
	            HEIGHT = 480;
	            break;
	        default:
	            WIDTH = 800;
	            HEIGHT = 480;
	            break;
	    }
	    
		// ---------------------------------------- Fin de Control de resolucion
	    
	    // ---------------------------------------- Actualizacion de variables relativas
	    
	    entitiesSize = (int) (anchoResponsive * 0.045);
	    alturaResponsive = getHeight();
	    anchoResponsive = getWidth();
	    
	    // ---------------------------------------- Fin de Actualizacion de variables relativas
	    
	    
		// ---------------------------------- Actualizacion de entidades
	    
		player.update(leftPressed, rightPressed, upPressed, downPressed, aPressed, dPressed, wPressed, sPressed, space, cPressed, structures);

		// ---------------------------------- Fin de Actualizacion de entidades
		
		
		// ---------------------------------- Actualizacion de grilla y sus niveles 
		
		// Actualizacion de grilla
	    int usableHeight = getHeight() - getInsets().top - getInsets().bottom;
	    int usableWidth = getWidth() - getInsets().left - getInsets().right;
	    int cuadriculaWidth = (int) (usableWidth * 0.75);
	    int numFilas = 10;
	    int numColumnas = 15;
	    int bloqueWidth = cuadriculaWidth / numColumnas;
	    int bloqueHeight = usableHeight / numFilas;
	    offsetX = (cuadriculaWidth - (bloqueTam * numColumnas)) / 2;
	    offsetY = (usableHeight - (bloqueTam * numFilas)) / 2;
	    bloqueTam = Math.min(bloqueWidth, bloqueHeight);
	    
	  
		// ---------------------------------- Fin de Actualizacion de grilla y sus niveles 

	    

		// Actualizar el tiempo jugado
        elapsedTime = System.nanoTime() - startTime; // Calcular tiempo transcurrido
	}
	

	// --------------------------------------------------- Metodo que dibuja el juego
	
	private void draw() {
	    bs = canvas.getBufferStrategy();
	    if (bs == null) {
	        canvas.createBufferStrategy(3);
	        return;
	    }
	    
	    g = bs.getDrawGraphics();
	    
	    // -------------- FONDO DEFAULT -----------------------
	    g.setColor(Color.gray);
	    g.fillRect(0, 0, getWidth(), getHeight());
	    // -------------- FIN FONDO DEFAULT -------------------
	    

	    // ---------------------------------------------------- GRILLA
	    int usableHeight = getHeight() - getInsets().top - getInsets().bottom;
	    int usableWidth = getWidth() - getInsets().left - getInsets().right;
	    int cuadriculaWidth = (int) (usableWidth * 0.75);
	    int tablaWidth = (int) (usableWidth * 0.25);
	    g.setColor(Color.black);
	    g.fillRect(0, 0, cuadriculaWidth, usableHeight);
	    
	    int numFilas = 10;
	    int numColumnas = 15;
	    int bloqueWidth = cuadriculaWidth / numColumnas;
	    int bloqueHeight = usableHeight / numFilas;
	    bloqueTam = Math.min(bloqueWidth, bloqueHeight);
	    int offsetX = (cuadriculaWidth - (bloqueTam * numColumnas)) / 2;
	    int offsetY = (usableHeight - (bloqueTam * numFilas)) / 2;
	    
	    // Dibujo y actualizacion de niveles 
	    switch(nivelSeleccionado) {
	    	case 1:
	    		level1.draw(g, numColumnas, numFilas, bloqueTam, offsetX, offsetY, frameSeleccionado);
		    	level1.update(frameSeleccionado, structures, bloqueTam, offsetX, offsetY);
	    	break;
	    	
	    	case 2:
	    	break;
	    	
	    	case 3:
	    	break;
	    	
	    	case 4:
	    	break;
	    	
	    	case 5:
	    	break;
	    }
	    
	    // ---------------------------------------------------- FIN GRILLA
	    
	    // ---------------------------------------------------- BARRA LATERAL
	
        // Gradiente suave en lugar de un fondo sólido
        GradientPaint gradient = new GradientPaint(
            cuadriculaWidth, 0, new Color(45, 45, 48), 
            cuadriculaWidth + tablaWidth, usableHeight, new Color(30, 30, 34));
        Graphics2D g2d = (Graphics2D) g;
        g2d.setPaint(gradient);
        g2d.fillRect(cuadriculaWidth, 0, tablaWidth, usableHeight);

	    // Texto estilizado
	    g.setColor(Color.WHITE);
	    g.setFont(new Font("Smash", Font.PLAIN, (int)(Window.anchoResponsive * 0.028)));
	    g.drawString("MARCADOR: " + puntuacion, cuadriculaWidth + (int)(Window.anchoResponsive * 0.025), (int)(Window.alturaResponsive * 0.1));
	    
	    g.setColor(Color.RED);
	    g.setFont(new Font("Smash", Font.PLAIN, (int)(Window.anchoResponsive * 0.028)));
	    g.drawString("BAJAS: " + puntuacion, cuadriculaWidth + (int)(Window.anchoResponsive * 0.06), (int)(Window.alturaResponsive * 0.2));
	    
	    
	    g.setColor(Color.WHITE);
	    g.setFont(new Font("Smash", Font.BOLD, (int)(Window.anchoResponsive * 0.02)));
	    g.drawString("VIDAS: " + player.getHealth(), cuadriculaWidth + (int)(Window.anchoResponsive * 0.0725), (int)(Window.alturaResponsive * 0.3));
	    
	    g.setFont(new Font("Smash", Font.BOLD, (int)(Window.anchoResponsive * 0.02))); // Fuente más moderna
	    g.setColor(Color.WHITE);
	    int seconds = (int) (elapsedTime / 1_000_000_000); // Convertir de nanosegundos a segundos
	    g.drawString("TIEMPO: " + seconds + "s", cuadriculaWidth + (int)(Window.anchoResponsive * 0.062), (int)(Window.alturaResponsive * 0.9));
	    
	    // ---------------------------------------------------- FIN BARRA LATERAL

	    // ------------------------------------------- Dibujo de entidades
	    
	    player.draw(g);
	    
	    for (Structure structure : structures) {
	        structure.draw(g);
	    }
	    
	    // ------------------------------------------- Fin de Dibujo de entidades
	    
	    g.dispose();
	    bs.show();
	}
	
	// --------------------------------------------------- Funciones para empezar/detener el juego
	
	public void run() {
		long now = 0;
		long lastTime = System.nanoTime();
		
		while(running) {
			now = System.nanoTime();
			delta += (now - lastTime) / TARGETTIME;
			lastTime = now;
			
			if (delta >= 1) {
				update();
				draw();
				delta--;
			}
		}
		stop();
	}
	
	public synchronized void start() {
		thread = new Thread(this);
		thread.start();
		running = true;
	}
	
	public synchronized void stop() {
		try {
			thread.join();
			running = false;
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	// --------------------------------------------------- Fin de Funciones para empezar/detener el juego
	
	// --------------------------------------------------- Funciones de teclas
	@Override
	public void keyPressed(KeyEvent e) {
		switch (e.getKeyCode()) {
		case KeyEvent.VK_A:
			aPressed = true;
			break;
		case KeyEvent.VK_D:
			dPressed = true;
			break;
		case KeyEvent.VK_W:
			wPressed = true;
			break;
		case KeyEvent.VK_S:
			sPressed = true;
			break;
		case KeyEvent.VK_LEFT:
			leftPressed = true;
			break;
		case KeyEvent.VK_RIGHT:
			rightPressed = true;
			break;
		case KeyEvent.VK_UP:
			upPressed = true;
			break;
		case KeyEvent.VK_DOWN:
			downPressed = true;
			break;
		case KeyEvent.VK_C:
			cPressed = true;
			break;
		case KeyEvent.VK_SPACE:
			space = true;
			break;
		}
	}
	
	@Override
	public void keyReleased(KeyEvent e) {
		switch (e.getKeyCode()) {
		case KeyEvent.VK_A:
			aPressed = false;
			break;
		case KeyEvent.VK_D:
			dPressed = false;
			break;
		case KeyEvent.VK_W:
			wPressed = false;
			break;
		case KeyEvent.VK_S:
			sPressed = false;
			break;
		case KeyEvent.VK_LEFT:
			leftPressed = false;
			break;
		case KeyEvent.VK_RIGHT:
			rightPressed = false;
			break;
		case KeyEvent.VK_UP:
			upPressed = false;
			break;
		case KeyEvent.VK_DOWN:
			downPressed = false;
			break;
		case KeyEvent.VK_C:
			cPressed = false;
			break;
		case KeyEvent.VK_SPACE:
			space = false;
			break;
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// no se necesita
	}
	
	public int getOffsetX() {
		return offsetX;
	}
	
	public int getOffsetY() {
		return offsetY;
	}
	
	// --------------------------------------------------- Fin de Funciones de teclas
}