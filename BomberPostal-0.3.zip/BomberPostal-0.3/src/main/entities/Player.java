package main.entities;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.File;
import java.io.IOException;



import main.ui.Window;

public class Player {
    // -------------------------- Declaracion de variables --------------------------
    
    // Atributos generales del jugador
    private int x, y;
    private int sizeWidth, sizeHeight; 
    private double speed;
    private double speedPower = 1;
    private Color color;

    private Clip walkSound; // Para almacenar el sonido de caminar
    
    // Vida
    public int vida = 3;

    // Bombas
    private List<Bomb> bombs = new ArrayList<>();
    private long lastBombTime = 0; 
    private final long BOMB_DELAY = 5000; 
    private int MAX_BOMBS = 3; // Máximo número de bombas que puede tener el jugador
    private int remainingBombs = 2;  // Bombas iniciales del jugador (empieza con 2)

    // Balas
    private List<Bullet> bullets = new ArrayList<>();
    private long lastShootTime = 0; 
    private final long SHOOT_DELAY = 390; 
    private int lastDirection = -1;
    private int MAX_BULLETS = 10; // Cantidad máxima de balas
    private int remainingBullets = MAX_BULLETS; // Balas restantes
    
    // Estructuras
    private List<Structure> structures;

    // ------------------------------------------------------------------------------

    public Player(double speed, Color color, List<Structure> structures) {
        this.speed = speed;
        this.color = color;
        this.structures = structures;
        updateDimensions();
        this.x = 128;
        this.y = 128;
        
        loadWalkSound(); // Cargar el sonido de caminar
    }
    
    private void loadWalkSound() {
        try {
            // Ruta del archivo de sonido
        	File soundFile = new File("assets/sounds/Sonidos/paso_alfombra.wav");

            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(soundFile);
            walkSound = AudioSystem.getClip();
            walkSound.open(audioInputStream);
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            e.printStackTrace();
        }
    }

    private void playWalkSound() {
        if (walkSound != null && !walkSound.isRunning()) { // Asegurarse de no superponer el sonido
            walkSound.setFramePosition(0); // Reproducir desde el inicio
            walkSound.start();
        }
    }

    public void updateDimensions() {
        this.sizeWidth = (int) (Window.anchoResponsive * 0.05); 
        this.sizeHeight = (int) (Window.anchoResponsive * 0.05);
    }

    public void update(boolean left, boolean right, boolean space, boolean up, boolean a, boolean d, boolean w, boolean s, boolean down, boolean shoot, List<PowerUp> powerUps) {
        speed = (Window.anchoResponsive * 0.0033) * speedPower;
        sizeWidth = Window.bloqueTam - (int) (Window.anchoResponsive * 0.01);
        sizeHeight = Window.bloqueTam - (int) (Window.anchoResponsive * 0.01);
        
        long currentTime = System.currentTimeMillis();
        
        // ----------------------------------------------------- Movimiento
        boolean moved = false;
        
        int newX = x;
        int newY = y;

        if (left || a) {
            newX -= speed;
            if (!checkCollision(newX, y)) {
                x = newX;
                lastDirection = 2; // Izquierda
                moved = true;
            }
        }
        if (right || d) {
            newX += speed;
            if (!checkCollision(newX, y)) {
                x = newX;
                lastDirection = 0; // Derecha
                moved = true;
            }
        }
        if (up || w) {
            newY -= speed;
            if (!checkCollision(x, newY)) {
                y = newY;
                lastDirection = 1; // Arriba
                moved = true;
            }
        }
        if (down || s) {
            newY += speed;
            if (!checkCollision(x, newY)) {
                y = newY;
                lastDirection = 3; // Abajo
                moved = true;
            }
        }

        // Si el jugador se ha movido, reproducir el sonido de caminar
        if (moved) {
            playWalkSound();
        }
        
        x = Math.max(Window.limiteJugadorIzquierda, Math.min(x,Window.limiteJugadorDerecha));
        y = Math.max(Window.limiteJugadorArriba, Math.min(y,Window.limiteJugadorAbajo));
     
        // ----------------------------------------------------- Bombas
        if (space && remainingBombs > 0 && (currentTime - lastBombTime) >= BOMB_DELAY) {
            bombs.add(new Bomb(x + sizeWidth / 2 - (int) (Window.anchoResponsive * 0.019), y + sizeHeight / 2 - (int) (Window.anchoResponsive * 0.019)));
            lastBombTime = currentTime;
            remainingBombs--; // Reducir la cantidad de bombas disponibles
        }

        // Actualizar bombas
        for (int i = 0; i < bombs.size(); i++) {
            bombs.get(i).update();
            if (bombs.get(i).hasExploded()) {
                bombs.remove(i);
                i--;
            }
        }

        // ----------------------------------------------------- Balas
        if (shoot && remainingBullets > 0 && (currentTime - lastShootTime) >= SHOOT_DELAY) {
            if (lastDirection != -1) {
                bullets.add(new Bullet(x + sizeWidth / 2 - 5, y + sizeHeight / 2 - 5, lastDirection));
                lastShootTime = currentTime;
                remainingBullets--; // Reducir la cantidad de balas
            }
        }

        // Actualizar balas y verificar colisiones
        for (int i = 0; i < bullets.size(); i++) {
            Bullet bullet = bullets.get(i);
            bullet.update(structures);

            // Verificar colisiones con las estructuras
            for (Structure structure : structures) {
                if (bullet.collidesWith(structure)) {
                    bullet.deactivate(); // Desactivar la bala si colisiona
                    break; // Salir del bucle si la bala colisiona con cualquier estructura
                }
            }

            // Eliminar balas inactivas
            if (!bullet.isActive()) {
                bullets.remove(i);
                i--; // Decrementar i para mantener la posición correcta
            }
        }

        // ---------------------------------------------------------- Power Ups
        for (int i = 0; i < powerUps.size(); i++) {
            PowerUp powerUp = powerUps.get(i);
            if (checkPowerUpCollision(powerUp)) {
            	if(powerUps.get(i).tipo == 1) {
                    increaseSpeed(); // Aumentar la velocidad
            	}

            	else if(powerUps.get(i).tipo == 2) {
            		MAX_BULLETS+=5;
            	}
            	
            	else if(powerUps.get(i).tipo == 3) {
            		MAX_BOMBS++;
            	}
            	
            	else if(powerUps.get(i).tipo == 4) {
            		vida+=2;
            	}
                powerUps.remove(i); // Eliminar el powerup del juego después de recogerlo
                i--; 
            }
        }
    }

    private boolean checkCollision(int newX, int newY) {
        for (Structure structure : structures) {
            if (newX < structure.getX() + structure.getWidth() &&
                newX + sizeWidth > structure.getX() &&
                newY < structure.getY() + structure.getHeight() &&
                newY + sizeHeight > structure.getY()) {
                return true; // Hay colisión
            }
        }
        return false; // No hay colisión
    }
    
    public void increaseSpeed() {
        speedPower = 1.15; // Aumenta la velocidad en un 25%
    }

    public boolean checkPowerUpCollision(PowerUp powerUp) {
        return x < powerUp.getX() + powerUp.getWidth() &&
               x + sizeWidth > powerUp.getX() &&
               y < powerUp.getY() + powerUp.getHeight() &&
               y + sizeHeight > powerUp.getY();
    }

    public void draw(Graphics g) {
        
        // Jugador
        g.setColor(color);
        g.fillRect(x, y, sizeWidth, sizeHeight); 

        // Bombas
        for (Bomb bomb : bombs) {
            bomb.draw(g);
        }
        
        // Balas
        for (Bullet bullet : bullets) {
            bullet.draw(g);
        }
        
        // Dibujar estructuras
        for (Structure structure : structures) {
            structure.draw(g);
        }
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
    
    public int getWidth() {
        return sizeWidth;
    }
    
    public int getHeight() {
        return sizeHeight;
    }

    public int getRemainingBullets() {
        return remainingBullets; // Para obtener la cantidad de balas restantes
    }
}
