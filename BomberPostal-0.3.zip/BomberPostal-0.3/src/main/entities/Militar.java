package main.entities;

public class Militar {

}
