import main.ui.Menu_Screen;

public class Game {

	public static void main(String[] args) {
		new Menu_Screen().start();
	}	
	
}
