package main.entities.environment;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

public class Structure {
    public int x, y, tipo;
    private int width, height;
    private Color color; // Color opcional si no se proporciona imagen
    public Image image; // Imagen opcional
    public int bulletHits; // Contador de impactos de balas
    private boolean destroyed; // Para saber si la estructura está destruida

    // Constructor que acepta imagen
    public Structure(int x, int y, int width, int height, Image image, int tipo) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.image = image;
        this.color = null; // No hay color en este caso
        this.tipo = tipo;
        this.bulletHits = 0; // Inicialmente no ha recibido impactos
        this.destroyed = false; // No está destruida inicialmente
    }

    // Método que dibuja la estructura
    public void draw(Graphics g) {
        if (!destroyed) { // Solo dibuja si no está destruida
            if (image != null) {
                // Dibujar imagen si está presente
                g.drawImage(image, x, y, width, height, null);
            } else if (color != null) {
                // Dibujar el rectángulo con color si no hay imagen
                g.setColor(color);
                g.fillRect(x, y, width, height);
            } else {
                // Si no hay imagen ni color, dibujar un fondo verde
                g.setColor(Color.GREEN);
                g.fillRect(x, y, width, height);
            }
        }
        
        else {
        	x = -10000;
        	y = -10000;
        }
    }

    // Método para manejar los impactos de bala
    public void hitByBullet() {
        if (tipo == 1) { // Solo afecta a estructuras de tipo 1
            bulletHits++;
            if (bulletHits >= 2) {
                destroyed = true; // La estructura desaparece después de 2 balas
            }
        }
    }

    public boolean isDestroyed() {
        return destroyed;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }
    
    // Método para destruir la estructura
    public void setDestroyedTrue() {
        this.destroyed = true;
    }
    
    public void setDestroyedFalse() {
        this.destroyed = false;
    }
}
