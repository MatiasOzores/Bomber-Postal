package main.entities;

public class Inocentes {

}
