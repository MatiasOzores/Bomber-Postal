package main.entities;

public class Suicida {

}
