package main.entities;

public class Policia {

}
