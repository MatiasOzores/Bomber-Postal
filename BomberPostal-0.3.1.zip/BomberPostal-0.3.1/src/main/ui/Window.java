package main.ui;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferStrategy;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

import main.entities.Player;
import main.entities.PowerUp;
import main.entities.Structure;

public class Window extends JFrame implements Runnable, KeyListener {

	// -------------------------- Declaracion de variables --------------------------
	
	// aux
	private int invalido = 0;
	
	// general
	private static final long serialVersionUID = 1L;
    public static int WIDTH = 1280;
	public static int HEIGHT = 720;
    public static int alturaResponsive;
    public static int anchoResponsive;
	private Canvas canvas;
	private Thread thread;
	private boolean running;
	
	// para dibujos/graficos
	private BufferStrategy bs;
	private Graphics g;
	
	// para los frames
	private final int FPS = 60;
	private double TARGETTIME = 1000000000/FPS;
	private double delta = 0;
	
	// para entidades
    private Player player;
    private List<PowerUp> powerUps;
    
    public int speedPlayer = 5;
    
    // relacionado a estructuras/bloques
    List<Structure> structures = new ArrayList<>();
    private int espaciado;
    
    // para eventos de teclado
    private boolean leftPressed = false;
    private boolean rightPressed = false;
    private boolean upPressed = false;
    private boolean downPressed = false;
    private boolean space = false;
    private boolean aPressed = false;
    private boolean dPressed = false;
    private boolean wPressed = false;
    private boolean sPressed = false;
    private boolean cPressed = false;
    
    // para controlar la resolucion
    public int resolucion = 2;
    public static int bloqueTam;  // Tamaño de los bloques de la cuadrícula
    
    // Tabla lateral derecha
    public static int puntuacion = 0;
    
    // Cronómetro
    private long startTime;
    private long elapsedTime; // Tiempo jugado en milisegundos
    
    // Controlar niveles y frames
    public int nivelSeleccionado = 1;
    public int frameSeleccionado = 1;
    
    Font font = new Font("Dirty Headline", Font.BOLD, (int)(Window.anchoResponsive * 0.06));
    
    // Establecer limites del jugador con los bordes
    public static int limiteJugadorIzquierda, limiteJugadorDerecha, limiteJugadorArriba, limiteJugadorAbajo;
    
    // ------------------------------------------------------------------------------ Imagenes
    private Image barraLateralImage;
    
    
    // Imagenes estructuras N1 F1
    private Image 
    
    N1F1PA1,N1F1PA2,N1F1PA3,N1F1PA4,N1F1PA5,N1F1PA6,N1F1PA7,N1F1PA8,N1F1PA9,N1F1INTERIOR, N1F1SUELO, N1F1BORDE, N1F1ESQ_IZQ_INF, 
    N1F1ESQ_IZQ_SUP, N1F1ESQ_DER_INF, N1F1ESQ_DER_SUP, N1F1PD, N1F1PL, N1F1PR ,N1F1PU, impresora, planta, trapeador,
    
    N1F2PA1,N1F2PA2,N1F2PA3,N1F2PA4,N1F2PA5,N1F2PA6,N1F2PA7,N1F2PA8,N1F2PA9,N1F2INTERIOR, N1F2SUELO, N1F2BORDE, N1F2ESQ_IZQ_INF, 
    N1F2ESQ_IZQ_SUP, N1F2ESQ_DER_INF, N1F2ESQ_DER_SUP, N1F2PD, N1F2PL, N1F2PR ,N1F2PU, latas,
    
    N1F3PA, N1F3SUELO, N1F3BORDE, N1F3ESQ_IZQ_INF, N1F3ALFOMBRA ,
    N1F3ESQ_IZQ_SUP, N1F3ESQ_DER_INF, N1F3ESQ_DER_SUP, N1F3PD, N1F3PL, N1F3PR ,N1F3PU;  
    
    // ------------------------------------------------------------------------------ Fin Imagenes
    
    
    // Variables pos-optimizacion
    
    public static int entitiesSize = 0;
    
	// ------------------------------------------------------------------------------

	public Window() {
        setTitle("Bomber Postal");
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(true);
        setLocationRelativeTo(null);
        setVisible(true);
		
		canvas = new Canvas();
		canvas.setPreferredSize(new Dimension(WIDTH, HEIGHT));
		canvas.setFocusable(true);
		add(canvas);
	    canvas.addKeyListener(this);
       
        // Jugador
        player = new Player(bloqueTam * 0, bloqueTam * 0, entitiesSize, entitiesSize, 3, speedPlayer);        
        powerUps = new ArrayList<>();
        // Enemigos


        
        startTime = System.nanoTime();
        
        try {
            barraLateralImage = ImageIO.read(new File("assets/images/lateralImage.jpg"));
            N1F1PA1 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/ParedOficinaColumna.png"));
            N1F1PA2 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/ParedOficinaExtremoDerecho.png"));
            N1F1PA3 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/ParedOficinaExtremoInferior.png"));
            N1F1PA4 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/ParedOficinaExtremoIzquierdo.png"));
            N1F1PA5 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/ParedOficinaExtremoSuperior.png"));
            N1F1PA6 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/ParedOficinaInferiorDerecho.png"));
            N1F1PA7 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/ParedOficinaInferiorIzquierdo.png"));
            N1F1PA8 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/ParedOficinaSuperiorDerecho.png"));
            N1F1PA9 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/ParedOficinaSuperiorIzquierdo.png"));
            N1F1PD = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/ParedOficinaConexionDown.png"));
            N1F1PL = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/ParedOficinaConexionLeft.png"));
            N1F1PR = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/ParedOficinaConexionRight.png"));
            N1F1PU = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/ParedOficinaConexionUp.png"));
            N1F1SUELO = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/BaldosaOficina.png"));
            N1F1BORDE= ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/BloqueBordeOficina.png"));
            N1F1INTERIOR = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/InteriorPared.png"));
            N1F1ESQ_IZQ_INF = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/BordeOficinaEsquinaInferiorIzquierda.png"));
            N1F1ESQ_IZQ_SUP = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/BordeOficinaEsquinaSuperiorIzquierda.png"));
            N1F1ESQ_DER_INF = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/BordeOficinaEsquinaInferiorDerecha.png"));
            N1F1ESQ_DER_SUP = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/BordeOficinaEsquinaSuperiorDerecha.png"));
            impresora = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/Impresora.png"));
            planta = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/Planta.png"));
            trapeador = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/1_Oficina/Trapeador.png"));
            
            N1F2PA1 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/ParedSuperColumna.png"));
            N1F2PA2 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/ParedSuperExtremoDerecho.png"));
            N1F2PA3 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/ParedSuperExtremoInferior.png"));
            N1F2PA4 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/ParedSuperExtremoIziquierdo.png"));
            N1F2PA5 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/ParedSuperExtremoSuperior.png"));
            N1F2PA6 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/ParedSuperInferiorDerecho.png"));
            N1F2PA7 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/ParedSuperInferiorIzquierdo.png"));
            N1F2PA8 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/ParedSuperSuperiorDerecho.png"));
            N1F2PA9 = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/ParedSuperSuperiorIzquierdo.png"));
            N1F2SUELO = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/BaldosaSupermercado.png"));
            N1F2BORDE= ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/BloqueBordeSupermercado.png"));
            N1F2ESQ_IZQ_INF = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/BordeSuperEsquinaInferiorIzquierda.png"));
            N1F2ESQ_DER_INF = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/BordeSuperEsquinaInferiorDerecha.png"));
            N1F2ESQ_DER_SUP = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/BordeSuperEsquinaSuperiorDerecha.png")); 
            N1F2ESQ_IZQ_SUP = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/BordeSuperEsquinaSuperiorIzquierda.png"));
            latas = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/2_Supermercado/latas.png"));
            
            N1F3ALFOMBRA = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/3_Banco/AlfombraBanco.png"));
            N1F3BORDE = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/3_Banco/BloqueBordeBanco.png"));
            N1F3PA = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/3_Banco/ParedBanco.png"));
            N1F3SUELO = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/3_Banco/PisoBanco.png"));
            N1F3ESQ_IZQ_INF = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/3_Banco/BordeBancoEsquinaInferiorIzquierda.png"));
            N1F3ESQ_DER_INF = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/3_Banco/BordeBancoEsquinaInferiorDerecha.png"));
            N1F3ESQ_DER_SUP = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/3_Banco/BordeBancoEsquinaSuperiorDerecha.png")); 
            N1F3ESQ_IZQ_SUP = ImageIO.read(new File("assets/images/SpritesBomberPostal/Mapa/Dia1/3_Banco/BordeBancoEsquinaSuperiorIzquierda.png"));
            
            
            
            
        } catch (IOException e) {
            e.printStackTrace();
        }

	}
	
	// funcion que actualizara todo el juego (cada segundo literalmente)
	private void update() {
		
		// ---------------------------------------- Control de resolucion
	    switch (resolucion) {
	        case 1:
	            WIDTH = 1800;
	            HEIGHT = 900;
	            break;
	        case 2:
	            WIDTH = 1280;
	            HEIGHT = 720;
	            bloqueTam = 60;
	            break;
	        case 3:
	            WIDTH = 1366;
	            HEIGHT = 768;
	            break;
	        case 4:
	            WIDTH = 1024;
	            HEIGHT = 768;
	            break;
	        case 5:
	            WIDTH = 800;
	            HEIGHT = 480;
	            break;
	        default:
	            WIDTH = 800;
	            HEIGHT = 480;
	            break;
	    }
	    
		// ---------------------------------------- Control de resolucion
	    
	    // ---------------------------------------- Actualizacion de variables relativas
	    
	    entitiesSize = (int) (anchoResponsive * 0.045);
	    
	    // ----------------------------------------

	    setSize(WIDTH, HEIGHT);
	    canvas.setPreferredSize(new Dimension(WIDTH, HEIGHT));
	    canvas.revalidate();

	    // Obtener medidas de la ventana para el responsive
	    alturaResponsive = getHeight();
	    anchoResponsive = getWidth();
	    espaciado = getWidth() / 20;

		// ACTUALIZACION DE ENTIDADES
		player.update(leftPressed, rightPressed, upPressed, downPressed, aPressed, dPressed, wPressed, sPressed, space, cPressed, structures);

		 // Calcular dimensiones utilizables
	    int usableHeight = getHeight() - getInsets().top - getInsets().bottom;
	    int usableWidth = getWidth() - getInsets().left - getInsets().right;
	    
	    // Definir las dimensiones del área azul (cuadrícula) y verde (tabla)
	    int cuadriculaWidth = (int) (usableWidth * 0.75);
	    int tablaWidth = (int) (usableWidth * 0.25);

	    int numFilas = 10;
	    int numColumnas = 15;
	    
	    // Calcular el tamaño de los bloques para que se adapten a las dimensiones del área azul
	    int bloqueWidth = cuadriculaWidth / numColumnas;
	    int bloqueHeight = usableHeight / numFilas;
	    
	    // Usar el tamaño más pequeño para asegurar que los bloques quepan en ambos ejes
	    bloqueTam = Math.min(bloqueWidth, bloqueHeight);
	    
	    // Centrar la cuadrícula dentro del área azul
	    int offsetX = (cuadriculaWidth - (bloqueTam * numColumnas)) / 2;
	    int offsetY = (usableHeight - (bloqueTam * numFilas)) / 2;

	    
	    
	    if (nivelSeleccionado == 1) {
		    if(frameSeleccionado == 1 && invalido != 1) {
		    	
		    	// PRIMERA OFICINA. 
		    	
		    	 structures.add(new Structure(bloqueTam * 2 + offsetX, bloqueTam * 2 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 3 + offsetX, bloqueTam * 2 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 4 + offsetX, bloqueTam * 2 + offsetY , bloqueTam, bloqueTam, N1F1PA6));
		    	
		    	 structures.add(new Structure(bloqueTam * 2 + offsetX, bloqueTam * 3 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 2 + offsetX, bloqueTam * 4 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 
		    	 structures.add(new Structure(bloqueTam * 3 + offsetX, bloqueTam * 4 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 4 + offsetX, bloqueTam * 4 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 4 + offsetX, bloqueTam * 3 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 
		    	 structures.add(new Structure(bloqueTam * 3 + offsetX, bloqueTam * 3 + offsetY , bloqueTam, bloqueTam, N1F1PA3));

		    	 
		    	 // SEGUNDA OFICINA.
		    	 
		    	 structures.add(new Structure(bloqueTam * 7 + offsetX, bloqueTam * 2 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 8 + offsetX, bloqueTam * 2 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 9 + offsetX, bloqueTam * 2 + offsetY , bloqueTam, bloqueTam, N1F1PA6));
		    	 
		    	 structures.add(new Structure(bloqueTam * 7 + offsetX, bloqueTam * 3 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 7 + offsetX, bloqueTam * 4 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 
		    	 structures.add(new Structure(bloqueTam * 8 + offsetX, bloqueTam * 4 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 9 + offsetX, bloqueTam * 4 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 9 + offsetX, bloqueTam * 3 + offsetY , bloqueTam, bloqueTam, N1F1PA3));

		    	 structures.add(new Structure(bloqueTam * 8 + offsetX, bloqueTam * 3 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 
		    	 
		    	 // TERCERA OFICINA.
		    	 
		    	 structures.add(new Structure(bloqueTam * 2 + offsetX, bloqueTam * 6 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 3 + offsetX, bloqueTam * 6 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 4 + offsetX, bloqueTam * 6 + offsetY , bloqueTam, bloqueTam, N1F1PA6));

		    	 structures.add(new Structure(bloqueTam * 2 + offsetX, bloqueTam * 7 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 2 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 
		    	 structures.add(new Structure(bloqueTam * 3 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 4 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 4 + offsetX, bloqueTam * 7 + offsetY , bloqueTam, bloqueTam, N1F1PA3));

		    	 structures.add(new Structure(bloqueTam * 3 + offsetX, bloqueTam * 7 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 
		    	 
		    	 // CUARTA OFICINA.
		    	 
		    	 structures.add(new Structure(bloqueTam * 7 + offsetX, bloqueTam * 6 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 8 + offsetX, bloqueTam * 6 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 9 + offsetX, bloqueTam * 6 + offsetY , bloqueTam, bloqueTam, N1F1PA6));

		    	 structures.add(new Structure(bloqueTam * 7 + offsetX, bloqueTam * 7 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 7 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 
		    	 structures.add(new Structure(bloqueTam * 8 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 9 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 9 + offsetX, bloqueTam * 7 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 
		    	 structures.add(new Structure(bloqueTam * 8 + offsetX, bloqueTam * 7 + offsetY , bloqueTam, bloqueTam, N1F1PA3));

		    	 
		    	// OBJETOS EXTRAS (COMO IMPRESORAS Y TAL)
		    	 
  	 /*impresora*/ 	 structures.add(new Structure(bloqueTam * 1 + offsetX, bloqueTam * 3 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
   	 /*impresora*/	 structures.add(new Structure(bloqueTam * 1 + offsetX, bloqueTam * 7 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
  	 /*plantas */	 structures.add(new Structure(bloqueTam * 6 + offsetX, bloqueTam * 1 + offsetY , bloqueTam, bloqueTam, N1F1PA3));		
	 /*trapeador*/	 structures.add(new Structure(bloqueTam * 13 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 
		    	 
		    	 
		    	 // OFICINAS LATERALES
		    	 
		    	 structures.add(new Structure(bloqueTam * 11 + offsetX, bloqueTam * 1 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 12 + offsetX, bloqueTam * 1 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 13 + offsetX, bloqueTam * 1 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 
		    	 structures.add(new Structure(bloqueTam * 11 + offsetX, bloqueTam * 3 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 12 + offsetX, bloqueTam * 3 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 13 + offsetX, bloqueTam * 3 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 
		    	 structures.add(new Structure(bloqueTam * 11 + offsetX, bloqueTam * 5 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 12 + offsetX, bloqueTam * 5 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 13 + offsetX, bloqueTam * 5 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 
		    	 structures.add(new Structure(bloqueTam * 11 + offsetX, bloqueTam * 7 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 12 + offsetX, bloqueTam * 7 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		    	 structures.add(new Structure(bloqueTam * 13 + offsetX, bloqueTam * 7 + offsetY , bloqueTam, bloqueTam, N1F1PA3));
		
		    	 
		    	 // ...::::ASIGNARLE TEXTURA A LAS ESTRUCTURAS:::...  ￣へ￣   (〃＞目＜)
		    	 
		    
		    	 
		    	 // PRIMERA OFICINA. 
		    	 structures.get(0).image = N1F1PA9 ;   // ---->
		    	 structures.get(1).image = N1F1PU ;
		    	 structures.get(2).image = N1F1PA8 ;
		    	 
		    	 structures.get(3).image = N1F1PL ;       	  //  	   |
		    	 structures.get(4).image = N1F1PA7 ;			//	   ‿ 	
		    	 	
		    	 
		    	 structures.get(5).image = N1F1PD ;  	  // ---->       
		    	 structures.get(6).image = N1F1PA6 ;
		    	 structures.get(7).image = N1F1PR ;
		    	
		    	 structures.get(8).image = N1F1INTERIOR ;
		    
		    	 
		    	 // SEGUNDA OFICINA. 
		    	 
		    	 structures.get(9).image = N1F1PA9 ;
		    	 structures.get(10).image = N1F1PU ;
		    	 structures.get(11).image = N1F1PA8 ;
		    	 
		    	 structures.get(12).image = N1F1PL ;       	  //  	   |
		    	 structures.get(13).image = N1F1PA7 ;
		    	 
		    	 structures.get(14).image = N1F1PD ;  	  // ---->       
		    	 structures.get(15).image = N1F1PA6 ;
		    	 structures.get(16).image = N1F1PR ;
		    	 structures.get(17).image = N1F1INTERIOR ;
		    	 
		    	 
		    	 // TERCERA OFICINA. 
		    	 
		    	 
		    	 structures.get(18).image = N1F1PA9 ;   // ---->
		    	 structures.get(19).image = N1F1PU ;
		    	 structures.get(20).image = N1F1PA8 ;
		    	 
		    	 structures.get(21).image = N1F1PL ;       	  //  	   |
		    	 structures.get(22).image = N1F1PA7 ;			//	   ‿ 	
		    	 	
		    	 
		    	 structures.get(23).image = N1F1PD ;  	  
		    	 structures.get(24).image = N1F1PA6 ;
		    	 structures.get(25).image = N1F1PR ;
		    	 
		    	 structures.get(26).image = N1F1INTERIOR ;
		    	 
		    	 
		    	 // CUARTA OFICINA.
		    	 
		    	 structures.get(27).image = N1F1PA9 ;
		    	 structures.get(28).image = N1F1PU ;
		    	 structures.get(29).image = N1F1PA8 ;
		    	 
		    	 structures.get(30).image = N1F1PL ;       	  //  	   |
		    	 structures.get(31).image = N1F1PA7 ;
		    	 
		    	 structures.get(32).image = N1F1PD ;  	  // ---->       
		    	 structures.get(33).image = N1F1PA6 ;
		    	 structures.get(34).image = N1F1PR ;
		    	 
		    	 structures.get(35).image = N1F1INTERIOR ;

		    	
		    	// OBJETOS
		    	 
 /* impresora */  structures.get(36).image = impresora ;
 /* impresora */  structures.get(37).image = impresora ;
 
 /* plantas */  structures.get(38).image = trapeador ;
 /* puertas */  structures.get(39).image = planta ; // ACA

 
 

		    	





		    	 
		    	 
		    	 
		    	 
		    	 
		    	 
		    	// structures.get(6).image = N1F1PD ;
		    	 // Mensaje para Amodeo: Podes modificar los 3 atributos de las estructuras, la imagen y la posicion de x e y. 
		    	 /* 
		    	  * 
		    	  * Tu trabajo va ser estructurar un mapa de cada uno de los frames del juego a lo largo de todo el proyecto
		    	  * Es mas de creatividad que otra cosa, porque programarlo la verdad es que es muy facil, solo mueves los bloques y le cambias la imagen para que vayan acorde a la estructura
		    	  * Por cada frame te voy a decir la tematica para que te orientes mejor por ejemplo el primero se trata de una oficina. Por ahora el sistema de niveles es asi, todavia no lo separe por clases porque se me complico
		    	  * Solo me vas a proporcionar toda esta parte del codigo con todos las estructuras colocadas perfectamente, es decir, todo lo que abarca if(frameSeleccionado == 1 && invalido != 1) { } todo lo que estaria dentro de estas dos llaves
		    	  * Osea donde estoy escribiendo aca dentro, todo eso.
		    	  * 
		    	  * Pautas: En este primer frame sentite libre de crear todas las estructuras que quieras con structures.add(new Structure(bloqueTam * 2 + offsetX, bloqueTam * 3 + offsetY , bloqueTam, bloqueTam, N1F1PA1)); 
		    	  * 
		    	  * Luego en los siguientes frames te voy a ir diciendo que cosas van cambiando.
		    	  *  
		    	  *  
		    	  *  
		    	  * */
			    
		    	 
			    invalido = 1;
		    }   
		    
		    
		    else if(frameSeleccionado == 2 && invalido != 1) {
		    	
		    	 structures.add(new Structure(bloqueTam * 3 + offsetX, bloqueTam * 2 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 3 + offsetX, bloqueTam * 3 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 3 + offsetX, bloqueTam * 4 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 4 + offsetX, bloqueTam * 3 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 4 + offsetX, bloqueTam * 4 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 5 + offsetX, bloqueTam * 2 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 5 + offsetX, bloqueTam * 4 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 1 + offsetX, bloqueTam * 6 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 2 + offsetX, bloqueTam * 6 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 7 + offsetX, bloqueTam * 2 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 7 + offsetX, bloqueTam * 3 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 7 + offsetX, bloqueTam * 4 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 8 + offsetX, bloqueTam * 2 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 10 + offsetX, bloqueTam * 2 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 10 + offsetX, bloqueTam * 3 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 12 + offsetX, bloqueTam * 2 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 12 + offsetX, bloqueTam * 3 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 12 + offsetX, bloqueTam * 5 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 10 + offsetX, bloqueTam * 5 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 8 + offsetX, bloqueTam * 5 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 11 + offsetX, bloqueTam * 6 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 4 + offsetX, bloqueTam * 6 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 6 + offsetX, bloqueTam * 6 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 7 + offsetX, bloqueTam * 6 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 8 + offsetX, bloqueTam * 6 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 7 + offsetX, bloqueTam * 7 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 1 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 4 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 5 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 9 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 11 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 
		    	 structures.add(new Structure(bloqueTam * 1 + offsetX, bloqueTam * 4 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 2 + offsetX, bloqueTam * 4 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 3 + offsetX, bloqueTam * 5 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 4 + offsetX, bloqueTam * 5 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 5 + offsetX, bloqueTam * 5 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 4 + offsetX, bloqueTam * 1 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 5 + offsetX, bloqueTam * 1 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 6 + offsetX, bloqueTam * 3 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 8 + offsetX, bloqueTam * 1 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 9 + offsetX, bloqueTam * 1 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 11 + offsetX, bloqueTam * 2 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 12 + offsetX, bloqueTam * 4 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 10 + offsetX, bloqueTam * 4 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 10 + offsetX, bloqueTam * 4 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 13 + offsetX, bloqueTam * 1 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 13 + offsetX, bloqueTam * 2 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 1 + offsetX, bloqueTam * 7 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 2 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 5 + offsetX, bloqueTam * 7 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 7 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 8 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 10 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 11 + offsetX, bloqueTam * 7 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 10 + offsetX, bloqueTam * 6 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 9 + offsetX, bloqueTam * 5 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 9 + offsetX, bloqueTam * 5 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 12 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 

		    	 structures.add(new Structure(bloqueTam * 13 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
			
		    	 structures.add(new Structure(bloqueTam * 13 + offsetX, bloqueTam * 7 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 13 + offsetX, bloqueTam * 6 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 13 + offsetX, bloqueTam * 5 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 2 + offsetX, bloqueTam * 2 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 2 + offsetX, bloqueTam * 3 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 3 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 8 + offsetX, bloqueTam * 3 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 
		    	 structures.add(new Structure(bloqueTam * 8 + offsetX, bloqueTam * 4 + offsetY , bloqueTam, bloqueTam, N1F2PA3)); 

		    	 
		    	 
		    	 // ...::::ASIGNARLE TEXTURA A LAS ESTRUCTURAS:::...  (ㆆ_ㆆ)    ┗|｀O′|┛

		    	 structures.get(31).image = latas ;
		    	 structures.get(32).image = latas ; 
		    	 structures.get(33).image = latas ; 
		    	 structures.get(34).image = latas ; 
		    	 structures.get(35).image = latas ; 
		    	 structures.get(36).image = latas ; 
		    	 structures.get(37).image = latas ; 
		    	 structures.get(38).image = latas ; 
		    	 structures.get(39).image = latas ; 
		    	 structures.get(40).image = latas ; 
		    	 structures.get(41).image = latas ; 
		    	 structures.get(42).image = latas ; 
		    	 structures.get(43).image = latas ; 
		    	 structures.get(44).image = latas ; 
		    	 structures.get(45).image = latas ; 
		    	 structures.get(46).image = latas ; 
		    	 structures.get(47).image = latas ; 
		    	 structures.get(48).image = latas ; 
		    	 structures.get(49).image = latas ; 
		    	 structures.get(50).image = latas ; 
		    	 structures.get(51).image = latas ; 
		    	 structures.get(52).image = latas ; 
		    	 structures.get(53).image = latas ; 
		    	 structures.get(54).image = latas ; 
		    	 structures.get(55).image = latas ; 
		    	 structures.get(56).image = latas ; 
		    	 structures.get(57).image = latas ; 
		    	 structures.get(59).image = latas ; 
		    	 structures.get(60).image = latas ; 
		    	 structures.get(61).image = latas ; 
		    	 structures.get(62).image = latas ; 
		    	 structures.get(63).image = latas ; 
		    	 structures.get(64).image = latas ; 
		    	 structures.get(65).image = latas ; 
		    	 structures.get(66).image = latas ;

			    invalido = 1;
		    } 
		    else if(frameSeleccionado == 3 && invalido != 1) {
		    	
		    	
		    structures.add(new Structure(bloqueTam * 2 + offsetX, bloqueTam * 2 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 3 + offsetX, bloqueTam * 2 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 4 + offsetX, bloqueTam * 2 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 6 + offsetX, bloqueTam * 2 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 8 + offsetX, bloqueTam * 2 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 10 + offsetX, bloqueTam * 2 + offsetY , bloqueTam, bloqueTam, N1F3PA));
		    structures.add(new Structure(bloqueTam * 11 + offsetX, bloqueTam * 2 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 12 + offsetX, bloqueTam * 2 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 12 + offsetX, bloqueTam * 3 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 10 + offsetX, bloqueTam * 3 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 2 + offsetX, bloqueTam * 4 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 4 + offsetX, bloqueTam * 4 + offsetY , bloqueTam, bloqueTam, N1F3PA));
		    structures.add(new Structure(bloqueTam * 3 + offsetX, bloqueTam * 5 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 6 + offsetX, bloqueTam * 4 + offsetY , bloqueTam, bloqueTam, N1F3PA));
		    structures.add(new Structure(bloqueTam * 8 + offsetX, bloqueTam * 4 + offsetY , bloqueTam, bloqueTam, N1F3PA));
		    structures.add(new Structure(bloqueTam * 3 + offsetX, bloqueTam * 6 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 2 + offsetX, bloqueTam * 6 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 2 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    
		    structures.add(new Structure(bloqueTam * 3 + offsetX, bloqueTam * 7 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 3 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 1 + offsetX, bloqueTam * 6 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 1 + offsetX, bloqueTam * 3 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 2 + offsetX, bloqueTam * 3 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 3 + offsetX, bloqueTam * 1 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 5 + offsetX, bloqueTam * 3 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 5 + offsetX, bloqueTam * 4 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 7 + offsetX, bloqueTam * 4 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 8 + offsetX, bloqueTam * 3 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 8 + offsetX, bloqueTam * 1 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 7 + offsetX, bloqueTam * 2 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 9 + offsetX, bloqueTam * 2 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 10 + offsetX, bloqueTam * 1 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    
		    structures.add(new Structure(bloqueTam * 8 + offsetX, bloqueTam * 5 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 8 + offsetX, bloqueTam * 6 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 7 + offsetX, bloqueTam * 6 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 6 + offsetX, bloqueTam * 6 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    
		    structures.add(new Structure(bloqueTam * 5 + offsetX, bloqueTam * 6 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 4 + offsetX, bloqueTam * 6 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 9 + offsetX, bloqueTam * 4 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    
		    structures.add(new Structure(bloqueTam * 9 + offsetX, bloqueTam * 7 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 10 + offsetX, bloqueTam * 7 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 10 + offsetX, bloqueTam * 6 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 12 + offsetX, bloqueTam * 6 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 12 + offsetX, bloqueTam * 5 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 13 + offsetX, bloqueTam * 5 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 12 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 13 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 7 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 5 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 10 + offsetX, bloqueTam * 4 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    
		    structures.add(new Structure(bloqueTam * 13 + offsetX, bloqueTam * 1 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 13 + offsetX, bloqueTam * 3 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 13 + offsetX, bloqueTam * 4 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 12 + offsetX, bloqueTam * 4 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 11 + offsetX, bloqueTam * 5 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 11 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 8 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 6 + offsetX, bloqueTam * 8 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 
		    structures.add(new Structure(bloqueTam * 6 + offsetX, bloqueTam * 7 + offsetY , bloqueTam, bloqueTam, N1F3PA)); 

		    
















		   



		    		

		    
	    	 // ...::::ASIGNARLE TEXTURA A LAS ESTRUCTURAS:::...  	（づ￣3￣）づ╭❤～	 (￣o￣) . z Z
		    	
	   	 structures.get(18).image = N1F1INTERIOR ;
	   	 structures.get(19).image = N1F1INTERIOR ;
	   	 structures.get(20).image = N1F1INTERIOR ;
	   	 structures.get(21).image = N1F1INTERIOR ;
	   	 structures.get(22).image = N1F1INTERIOR ;
	   	 structures.get(23).image = N1F1INTERIOR ;
	   	 structures.get(24).image = N1F1INTERIOR ;
	   	 structures.get(25).image = N1F1INTERIOR ;
	   	 structures.get(26).image = N1F1INTERIOR ;
	   	 structures.get(27).image = N1F1INTERIOR ;
	   	 structures.get(28).image = N1F1INTERIOR ;
	   	 structures.get(29).image = N1F1INTERIOR ;
	   	 structures.get(30).image = N1F1INTERIOR ;
	   	 structures.get(31).image = N1F1INTERIOR ;
	   	 structures.get(36).image = N1F1INTERIOR ;
	   	 structures.get(37).image = N1F1INTERIOR ;
	   	 structures.get(38).image = N1F1INTERIOR ;
	   	 structures.get(50).image = planta ;
	   	structures.get(51).image = N1F1INTERIOR ;
	   	 structures.get(52).image = N1F1INTERIOR ;
	   	 structures.get(53).image = N1F1INTERIOR ;
	   	 structures.get(54).image = N1F1INTERIOR ;
	   	 structures.get(55).image = N1F1INTERIOR ;
	   	 structures.get(56).image = N1F1INTERIOR ;
	   	 structures.get(57).image = N1F1INTERIOR ;
	   	 structures.get(58).image = N1F1INTERIOR ;

		    
		    	invalido = 1;
		    } 
		    
		    }



		// Actualizar el tiempo jugado
        elapsedTime = System.nanoTime() - startTime; // Calcular tiempo transcurrido
	}
	
	
	// funcion que dibujara todo el juego (cada segundo literalmente)
	private void draw() {
	    bs = canvas.getBufferStrategy();
	    if (bs == null) {
	        canvas.createBufferStrategy(3);
	        return;
	    }
	    
	    g = bs.getDrawGraphics();
	    
	    // -------------- FONDO DEFAULT -----------------------
	    g.setColor(Color.gray);
	    g.fillRect(0, 0, getWidth(), getHeight());
	    // -------------- FIN FONDO DEFAULT -------------------
	    

	    // ---------------------------------------------------- GRILLA
	    int usableHeight = getHeight() - getInsets().top - getInsets().bottom;
	    int usableWidth = getWidth() - getInsets().left - getInsets().right;
	    int cuadriculaWidth = (int) (usableWidth * 0.75);
	    int tablaWidth = (int) (usableWidth * 0.25);
	    g.setColor(Color.black);
	    g.fillRect(0, 0, cuadriculaWidth, usableHeight);
	    
	    int numFilas = 10;
	    int numColumnas = 15;
	    int bloqueWidth = cuadriculaWidth / numColumnas;
	    int bloqueHeight = usableHeight / numFilas;
	    bloqueTam = Math.min(bloqueWidth, bloqueHeight);
	    int offsetX = (cuadriculaWidth - (bloqueTam * numColumnas)) / 2;
	    int offsetY = (usableHeight - (bloqueTam * numFilas)) / 2;
	    
	    for (int i = 0; i < numColumnas; i++) {
	        for (int j = 0; j < numFilas; j++) {
	            int x = offsetX + i * bloqueTam;
	            int y = offsetY + j * bloqueTam;
	            if(nivelSeleccionado == 1) {
	            	if(frameSeleccionado == 1) {
	            		
	            		// Arriba a la izquierda
	            		if(j == 0 && i == 0) {
			            	g.drawImage(N1F1ESQ_IZQ_SUP, x, y, bloqueTam, bloqueTam, null);
	            		}
	            		
	            		// Arriba a la derecha
	            		else if(j == 0 && i == numColumnas-1) {
			            	g.drawImage(N1F1ESQ_DER_SUP, x, y, bloqueTam, bloqueTam, null);
	            		}
	            		
	            		// Abajo a la derecha
	            		else if(j == numFilas-1 && i == numColumnas-1) {
			            	g.drawImage(N1F1ESQ_DER_INF, x, y, bloqueTam, bloqueTam, null);
	            		}
	            		
	            		// Abajo a la izquierda
	            		else if(j == numFilas-1 && i == 0) {
			            	g.drawImage(N1F1ESQ_IZQ_INF, x, y, bloqueTam, bloqueTam, null);
	            		}
	            		
	            		// Bordes de arriba 
	            		else if(j == 0) {
			            	g.drawImage(N1F1BORDE, x, y, bloqueTam, bloqueTam, null);		            		
		            	}
		            	
	            		// Bordes de abajo
		            	else if(j == numFilas - 1) {
		            	    Graphics2D g2d = (Graphics2D) g.create(); 
		            	    
		            	    g2d.rotate(Math.toRadians(180), x + bloqueTam / 2, y + bloqueTam / 2);
		            	    
		            	    g2d.drawImage(N1F1BORDE, x-1, y-1, bloqueTam, bloqueTam, null);
		            	    
		            	    g2d.dispose(); 
		            	}
		            	
	            		// Bordes de la izquierda
		            	else if(i == 0) {
		            	    Graphics2D g2d = (Graphics2D) g.create(); 
		            	    
		            	    g2d.rotate(Math.toRadians(-90), x + bloqueTam / 2, y + bloqueTam / 2);
		            	    
		            	    g2d.drawImage(N1F1BORDE, x-1, y, bloqueTam, bloqueTam, null);
		            	    g2d.dispose(); 
		            	    
		            	    limiteJugadorIzquierda = bloqueTam * 1 + offsetX;
		            	    limiteJugadorDerecha = (int)(bloqueTam * 13.25 + offsetX);
		            	    limiteJugadorArriba = (int)(bloqueTam * 1+ offsetY);
		            	    limiteJugadorAbajo = (int)(bloqueTam * 8.25 + offsetY);
		            	}
		            	
	            		// Bordes de la derecha
		            	else if(i == numColumnas - 1) {
		            	    Graphics2D g2d = (Graphics2D) g.create(); 
		            	    
		            	    g2d.rotate(Math.toRadians(90), x + bloqueTam / 2, y + bloqueTam / 2);
		            	    
		            	    g2d.drawImage(N1F1BORDE, x, y-1, bloqueTam, bloqueTam, null);
		            	    
		            	    g2d.dispose(); 	
		            	    

		            	}

		            		
	            		// Suelo
		            	else {
		            		g.drawImage(N1F1SUELO, x, y, bloqueTam, bloqueTam, null);
		            	}
	            	}
	            
	            	
	            	if(frameSeleccionado == 2) {
	            		
	            		// Arriba a la izquierda
	            		if(j == 0 && i == 0) {
			            	g.drawImage(N1F2ESQ_IZQ_SUP, x, y, bloqueTam, bloqueTam, null);
	            		}
	            		
	            		// Arriba a la derecha
	            		else if(j == 0 && i == numColumnas-1) {
			            	g.drawImage(N1F2ESQ_DER_SUP, x, y, bloqueTam, bloqueTam, null);
	            		}
	            		
	            		// Abajo a la derecha
	            		else if(j == numFilas-1 && i == numColumnas-1) {
			            	g.drawImage(N1F2ESQ_DER_INF, x, y, bloqueTam, bloqueTam, null);
	            		}
	            		
	            		// Abajo a la izquierda
	            		else if(j == numFilas-1 && i == 0) {
			            	g.drawImage(N1F2ESQ_IZQ_INF, x, y, bloqueTam, bloqueTam, null);
	            		}
	            		
	            		// Bordes de arriba 
	            		else if(j == 0) {
			            	g.drawImage(N1F2BORDE, x, y, bloqueTam, bloqueTam, null);		            		
		            	}
		            	
	            		// Bordes de abajo
		            	else if(j == numFilas - 1) {
		            	    Graphics2D g2d = (Graphics2D) g.create(); 
		            	    
		            	    g2d.rotate(Math.toRadians(180), x + bloqueTam / 2, y + bloqueTam / 2);
		            	    
		            	    g2d.drawImage(N1F2BORDE, x-1, y-1, bloqueTam, bloqueTam, null);
		            	    
		            	    g2d.dispose(); 
		            	}
		            	
	            		// Bordes de la izquierda
		            	else if(i == 0) {
		            	    Graphics2D g2d = (Graphics2D) g.create(); 
		            	    
		            	    g2d.rotate(Math.toRadians(-90), x + bloqueTam / 2, y + bloqueTam / 2);
		            	    
		            	    g2d.drawImage(N1F2BORDE, x-1, y, bloqueTam, bloqueTam, null);
		            	    g2d.dispose(); 
		            	    
		            	    limiteJugadorIzquierda = bloqueTam * 1 + offsetX;
		            	    limiteJugadorDerecha = (int)(bloqueTam * 13.25 + offsetX);
		            	    limiteJugadorArriba = (int)(bloqueTam * 1+ offsetY);
		            	    limiteJugadorAbajo = (int)(bloqueTam * 8.25 + offsetY);
		            	}
		            	
	            		// Bordes de la derecha
		            	else if(i == numColumnas - 1) {
		            	    Graphics2D g2d = (Graphics2D) g.create(); 
		            	    
		            	    g2d.rotate(Math.toRadians(90), x + bloqueTam / 2, y + bloqueTam / 2);
		            	    
		            	    g2d.drawImage(N1F2BORDE, x, y-1, bloqueTam, bloqueTam, null);
		            	    
		            	    g2d.dispose(); 	
		            	    

		            	}

		            		
	            		// Suelo
		            	else {
		            		g.drawImage(N1F2SUELO, x, y, bloqueTam, bloqueTam, null);
		            	} 
	            	}
	            	
	            	
	            	if(frameSeleccionado == 3) {
	            		
	            		// Arriba a la izquierda
	            		if(j == 0 && i == 0) {
			            	g.drawImage(N1F3ESQ_IZQ_SUP, x, y, bloqueTam, bloqueTam, null);
	            		}
	            		
	            		// Arriba a la derecha
	            		else if(j == 0 && i == numColumnas-1) {
			            	g.drawImage(N1F3ESQ_DER_SUP, x, y, bloqueTam, bloqueTam, null);
	            		}
	            		
	            		// Abajo a la derecha
	            		else if(j == numFilas-1 && i == numColumnas-1) {
			            	g.drawImage(N1F3ESQ_DER_INF, x, y, bloqueTam, bloqueTam, null);
	            		}
	            		
	            		// Abajo a la izquierda
	            		else if(j == numFilas-1 && i == 0) {
			            	g.drawImage(N1F3ESQ_IZQ_INF, x, y, bloqueTam, bloqueTam, null);
	            		}
	            		
	            		// Bordes de arriba 
	            		else if(j == 0) {
			            	g.drawImage(N1F3BORDE, x, y, bloqueTam, bloqueTam, null);		            		
		            	}
		            	
	            		// Bordes de abajo
		            	else if(j == numFilas - 1) {
		            	    Graphics2D g2d = (Graphics2D) g.create(); 
		            	    
		            	    g2d.rotate(Math.toRadians(180), x + bloqueTam / 2, y + bloqueTam / 2);
		            	    
		            	    g2d.drawImage(N1F3BORDE, x-1, y-1, bloqueTam, bloqueTam, null);
		            	    
		            	    g2d.dispose(); 
		            	}
		            	
	            		// Bordes de la izquierda
		            	else if(i == 0) {
		            	    Graphics2D g2d = (Graphics2D) g.create(); 
		            	    
		            	    g2d.rotate(Math.toRadians(-90), x + bloqueTam / 2, y + bloqueTam / 2);
		            	    
		            	    g2d.drawImage(N1F3BORDE, x-1, y, bloqueTam, bloqueTam, null);
		            	    g2d.dispose(); 
		            	    
		            	    limiteJugadorIzquierda = bloqueTam * 1 + offsetX;
		            	    limiteJugadorDerecha = (int)(bloqueTam * 13.25 + offsetX);
		            	    limiteJugadorArriba = (int)(bloqueTam * 1+ offsetY);
		            	    limiteJugadorAbajo = (int)(bloqueTam * 8.25 + offsetY);
		            	}
		            	
	            		// Bordes de la derecha
		            	else if(i == numColumnas - 1) {
		            	    Graphics2D g2d = (Graphics2D) g.create(); 
		            	    
		            	    g2d.rotate(Math.toRadians(90), x + bloqueTam / 2, y + bloqueTam / 2);
		            	    
		            	    g2d.drawImage(N1F3BORDE, x, y-1, bloqueTam, bloqueTam, null);
		            	    
		            	    g2d.dispose(); 	
		            	    

		            	}

		            		
	            		// Suelo
		            	else {
		            		g.drawImage(N1F3ALFOMBRA, x, y, bloqueTam, bloqueTam, null);
		            	} 
	            	}
	            	
	            	
	            }
	            
	              
	        }
	    }
	    // ---------------------------------------------------- FIN GRILLA
	    
	 // ---------------------------------------------------- BARRA LATERAL
	
        // Gradiente suave en lugar de un fondo sólido
        GradientPaint gradient = new GradientPaint(
            cuadriculaWidth, 0, new Color(45, 45, 48), 
            cuadriculaWidth + tablaWidth, usableHeight, new Color(30, 30, 34));
        Graphics2D g2d = (Graphics2D) g;
        g2d.setPaint(gradient);
        g2d.fillRect(cuadriculaWidth, 0, tablaWidth, usableHeight);


	    

	    // Texto estilizado
	    g.setColor(Color.WHITE);
	    g.setFont(new Font("Smash", Font.PLAIN, (int)(Window.anchoResponsive * 0.028)));
	    g.drawString("MARCADOR: " + puntuacion, cuadriculaWidth + (int)(Window.anchoResponsive * 0.025), (int)(Window.alturaResponsive * 0.1));
	    
	    g.setColor(Color.RED);
	    g.setFont(new Font("Smash", Font.PLAIN, (int)(Window.anchoResponsive * 0.028)));
	    g.drawString("BAJAS: " + puntuacion, cuadriculaWidth + (int)(Window.anchoResponsive * 0.06), (int)(Window.alturaResponsive * 0.2));
	    
	    
	    g.setColor(Color.WHITE);
	    g.setFont(new Font("Smash", Font.BOLD, (int)(Window.anchoResponsive * 0.02)));
	    g.drawString("VIDAS: " + player.getHealth(), cuadriculaWidth + (int)(Window.anchoResponsive * 0.0725), (int)(Window.alturaResponsive * 0.3));
	    
	    g.setFont(new Font("Smash", Font.BOLD, (int)(Window.anchoResponsive * 0.02))); // Fuente más moderna
	    g.setColor(Color.WHITE);
	    int seconds = (int) (elapsedTime / 1_000_000_000); // Convertir de nanosegundos a segundos
	    g.drawString("TIEMPO: " + seconds + "s", cuadriculaWidth + (int)(Window.anchoResponsive * 0.062), (int)(Window.alturaResponsive * 0.9));
	    
	    
	    


	    // ---------------------------------------------------- FIN BARRA LATERAL

        
	   
	    // Dibujar el jugador
	    player.draw(g);
	    
	    // Dibuja las estructuras
	    for (Structure structure : structures) {
	        structure.draw(g);
	    }
	    
	    g.dispose();
	    bs.show();
	}
	
	public void run() {
		long now = 0;
		long lastTime = System.nanoTime();
		
		while(running) {
			now = System.nanoTime();
			delta += (now - lastTime) / TARGETTIME;
			lastTime = now;
			
			if (delta >= 1) {
				update();
				draw();
				delta--;
			}
		}
		stop();
	}
	
	// funciones para empezar/detener el juego
	public synchronized void start() {
		thread = new Thread(this);
		thread.start();
		running = true;
	}
	
	public synchronized void stop() {
		try {
			thread.join();
			running = false;
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	// FUNCIONES PARA TECLAS
	@Override
	public void keyPressed(KeyEvent e) {
		switch (e.getKeyCode()) {
		case KeyEvent.VK_A:
			aPressed = true;
			break;
		case KeyEvent.VK_D:
			dPressed = true;
			break;
		case KeyEvent.VK_W:
			wPressed = true;
			break;
		case KeyEvent.VK_S:
			sPressed = true;
			break;
		case KeyEvent.VK_LEFT:
			leftPressed = true;
			break;
		case KeyEvent.VK_RIGHT:
			rightPressed = true;
			break;
		case KeyEvent.VK_UP:
			upPressed = true;
			break;
		case KeyEvent.VK_DOWN:
			downPressed = true;
			break;
		case KeyEvent.VK_C:
			cPressed = true;
			break;
		case KeyEvent.VK_SPACE:
			space = true;
			break;
		}
	}
	
	@Override
	public void keyReleased(KeyEvent e) {
		switch (e.getKeyCode()) {
		case KeyEvent.VK_A:
			aPressed = false;
			break;
		case KeyEvent.VK_D:
			dPressed = false;
			break;
		case KeyEvent.VK_W:
			wPressed = false;
			break;
		case KeyEvent.VK_S:
			sPressed = false;
			break;
		case KeyEvent.VK_LEFT:
			leftPressed = false;
			break;
		case KeyEvent.VK_RIGHT:
			rightPressed = false;
			break;
		case KeyEvent.VK_UP:
			upPressed = false;
			break;
		case KeyEvent.VK_DOWN:
			downPressed = false;
			break;
		case KeyEvent.VK_C:
			cPressed = false;
			break;
		case KeyEvent.VK_SPACE:
			space = false;
			break;
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// no se necesita
	}
}