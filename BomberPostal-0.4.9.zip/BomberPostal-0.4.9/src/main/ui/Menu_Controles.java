package main.ui;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferStrategy;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

public class Menu_Controles extends JFrame implements Runnable, KeyListener{
	


	// -------------------------- Declaracion de variables --------------------------
	
	private static final long serialVersionUID = 1L; 
	private Canvas canvas;
    private Thread thread;
    private boolean running;
    private boolean startGame = false;

    private BufferStrategy bs;
    private Graphics g;

    private Font tittleFont = new Font("Smash", Font.PLAIN, 60);
    private String tittle = "Undercraft";
    private Font messageFont = new Font("Smash", Font.PLAIN, 30);
    private String controls1 = "3. Presiona la C para 'DISPARAR'";
    private String controls2 = "2. Presiona el ESPACIO para 'PLANTAR BOMBAS'";
    private String controls3 = "1. Muevete con 'W,A,S,D' o con las flechas";    
    private String salir = "Enter o Escape para salir";
    
    // presiona enter
    private int blinkCounter = 0; // Contador para manejar el parpadeo
    private final int BLINK_INTERVAL = 800; // Intervalo de parpadeo (ajusta según sea necesario)
    
    private Window window;

    
	// ------------------------------------------------------------------------------
    
    public Menu_Controles() {
        // seteamos los valores que necesitamos si o si para el frame
        setTitle("Bomber Postal");
        setSize(Window.WIDTH, Window.HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);

        // instanciamos canvas y sus dimensiones (con las mismas dimensiones de window)
        canvas = new Canvas();
        canvas.setPreferredSize(new Dimension(Window.WIDTH, Window.HEIGHT));
        canvas.setMaximumSize(new Dimension(Window.WIDTH, Window.HEIGHT));
        canvas.setMinimumSize(new Dimension(Window.WIDTH, Window.HEIGHT));
        canvas.setFocusable(true);

        add(canvas);
        canvas.addKeyListener(this);
        
        setVisible(true);
        
    }

    public void update() {
        blinkCounter++;
        if (blinkCounter >= BLINK_INTERVAL) {
            blinkCounter = 0;
        }
    }

	
	public void draw() {
	    bs = canvas.getBufferStrategy();
	    if (bs == null) {
	        canvas.createBufferStrategy(3);
	        return;
	    }
	    g = bs.getDrawGraphics();
	    
	    g.setColor(Color.black);
	    g.fillRect(0, 0, Window.WIDTH, Window.HEIGHT);
	    // ---------------------------------------------- Empieza el dibujo

	    // Dibuja un mensaje
	    g.setFont(messageFont);
	    int messageWidth = g.getFontMetrics().stringWidth(controls1); // variable para centrar
	    g.setColor(Color.red);
	    g.drawString(controls1, ((Window.WIDTH / 2) - (messageWidth / 2)), (Window.HEIGHT / 2) - 20);
	    
	    int messageWidth2 = g.getFontMetrics().stringWidth(controls2); // variable para centrar
	    g.setColor(Color.red);
	    g.drawString(controls2, ((Window.WIDTH / 2) - (messageWidth2 / 2)), (Window.HEIGHT / 2) - 100);

	    int messageWidth3 = g.getFontMetrics().stringWidth(controls3); // variable para centrar
	    g.setColor(Color.red);
	    g.drawString(controls3, ((Window.WIDTH / 2) - (messageWidth3 / 2)), (Window.HEIGHT / 2) - 180);
	    
	    int salirWidth = g.getFontMetrics().stringWidth(salir);
	    g.setColor(Color.white);
	    g.drawString(salir, ((Window.WIDTH / 2) - (salirWidth / 2)), (Window.HEIGHT / 2) + 120);

	    
	    
	    
	    // ---------------------------------------------- Termina el dibujo

	    g.dispose();
	    bs.show();
	}

	
	
	@Override
	public void run() {
        while (running) {
            draw();
            update();
            if (startGame) {
                running = false;
                this.dispose(); // Cerrar el menú
                new Window().start(); // Iniciar el juego
            }
            
            /*
            if(startOptions) {
            	running = false;
            	this.dispose();
            	new Menu_Options().start();
            }
            
            */
        }
	}
	
	public void start() {
       thread = new Thread(this);
       thread.start();
       running = true;		
	}
	
	public void stop() {
        try {
            thread.join();
            running = false;
        } catch (InterruptedException e) {
            e.printStackTrace();
        }		
	}
	
    
    public static void openControles() {
        new Menu_Controles().start();
    }
	
	
	
	// Funciones --------------------------------------------------------------
	
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_ENTER || key == KeyEvent.VK_ESCAPE) {
            running = false; // Detiene el ciclo del juego
            dispose(); // Cierra la ventana
        }
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	

}
